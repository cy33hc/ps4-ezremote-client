#include <cstdint>

// OpenOrbis libc otherwise maps a very large heap on the first allocation.
// The gdd daemon only has ~10 MB of free flexible memory, so that mapping
// fails and malloc crashes at address 0x38. Keep the daemon heap small.
extern "C" uint64_t sceLibcHeapSize = 8 * 1024 * 1024;
