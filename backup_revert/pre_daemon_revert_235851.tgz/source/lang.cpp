#include <orbis/SystemService.h>
#include "string.h"
#include "stdio.h"
#include "config.h"
#include "util.h"
#include "lang.h"
#include <map>
#include <dirent.h>

#define LANG_ASSETS_ROOT WEB_ASSETS_ROOT "/langs"

char lang_identifiers[LANG_STRINGS_NUM][LANG_ID_SIZE] = {
	FOREACH_STR(GET_STRING)};

// This is properly populated so that emulator won't crash if an user launches it without language INI files.
char lang_strings[LANG_STRINGS_NUM][LANG_STR_SIZE] = {
	"Connection Settings",																			  // STR_CONNECTION_SETTINGS
	"Site",																							  // STR_SITE
	"Local",																						  // STR_LOCAL
	"Remote",																						  // STR_REMOTE
	"Messages",																						  // STR_MESSAGES
	"Update Software",																				  // STR_UPDATE_SOFTWARE
	"Connect",																						  // STR_CONNECT
	"Disconnect",																					  // STR_DISCONNECT
	"Search",																						  // STR_SEARCH
	"Refresh",																						  // STR_REFRESH
	"Server",																						  // STR_SERVER
	"Username",																						  // STR_USERNAME
	"Password",																						  // STR_PASSWORD
	"Port",																							  // STR_PORT
	"Pasv",																							  // STR_PASV
	"Directory",																					  // STR_DIRECTORY
	"Filter",																						  // STR_FILTER
	"Yes",																							  // STR_YES
	"No",																							  // STR_NO
	"Cancel",																						  // STR_CANCEL
	"Continue",																						  // STR_CONTINUE
	"Close",																						  // STR_CLOSE
	"Folder",																						  // STR_FOLDER
	"File",																							  // STR_FILE
	"Type",																							  // STR_TYPE
	"Name",																							  // STR_NAME
	"Size",																							  // STR_SIZE
	"Date",																							  // STR_DATE
	"New Folder",																					  // STR_NEW_FOLDER
	"Rename",																						  // STR_RENAME
	"Delete",																						  // STR_DELETE
	"Upload",																						  // STR_UPLOAD
	"Download",																						  // STR_DOWNLOAD
	"Select All",																					  // STR_SELECT_ALL
	"Clear All",																					  // STR_CLEAR_ALL
	"Uploading",																					  // STR_UPLOADING
	"Downloading",																					  // STR_DOWNLOADING
	"Overwrite",																					  // STR_OVERWRITE
	"Don't Overwrite",																				  // STR_DONT_OVERWRITE
	"Ask for Confirmation",																			  // STR_ASK_FOR_CONFIRM
	"Don't Ask for Confirmation",																	  // STR_DONT_ASK_CONFIRM
	"Always use this option and don't ask again",													  // STR_ALLWAYS_USE_OPTION
	"Actions",																						  // STR_ACTIONS
	"Confirm",																						  // STR_CONFIRM
	"Overwrite Options",																			  // STR_OVERWRITE_OPTIONS
	"Properties",																					  // STR_PROPERTIES
	"Progress",																						  // STR_PROGRESS
	"Updates",																						  // STR_UPDATES
	"Are you sure you want to delete this file(s)/folder(s)?",										  // STR_DEL_CONFIRM_MSG
	"Canceling. Waiting for last action to complete",												  // STR_CANCEL_ACTION_MSG
	"Failed to upload file",																		  // STR_FAIL_UPLOAD_MSG
	"Failed to download file",																		  // STR_FAIL_DOWNLOAD_MSG
	"Failed to read contents of directory or folder does not exist.",								  // STR_FAIL_READ_LOCAL_DIR_MSG
	"426 Connection closed.",																		  // STR_CONNECTION_CLOSE_ERR_MSG
	"426 Remote Server has terminated the connection.",												  // STR_REMOTE_TERM_CONN_MSG
	"300 Failed Login. Please check your username or password.",									  // STR_FAIL_LOGIN_MSG
	"426 Failed. Connection timeout.",																  // STR_FAIL_TIMEOUT_MSG
	"Failed to delete directory",																	  // STR_FAIL_DEL_DIR_MSG
	"Deleting",																						  // STR_DELETING
	"Failed to delete file",																		  // STR_FAIL_DEL_FILE_MSG
	"Deleted",																						  // STR_DELETED
	"Link",																							  // STR_LINK
	"Share",																						  // STR_SHARE
	"310 Failed",																					  // STR_FAILED
	"310 Failed to create file on local",															  // STR_FAIL_CREATE_LOCAL_FILE_MSG
	"Install",																						  // STR_INSTALL
	"Installing",																					  // STR_INSTALLING
	"Success",																						  // STR_INSTALL_SUCCESS
	"Failed",																						  // STR_INSTALL_FAILED
	"Skipped",																						  // STR_INSTALL_SKIPPED
	"Checking connection to remote HTTP Server",													  // STR_CHECK_HTTP_MSG
	"Failed connecting to HTTP Server",																  // STR_FAILED_HTTP_CHECK
	"Remote is not a HTTP Server",																	  // STR_REMOTE_NOT_HTTP
	"Package not in the /data or /mnt/usbX folder",													  // STR_INSTALL_FROM_DATA_MSG
	"Package is already installed",																	  // STR_ALREADY_INSTALLED_MSG
	"Install from URL",																				  // STR_INSTALL_FROM_URL
	"Could not read package header info",															  // STR_CANNOT_READ_PKG_HDR_MSG
	"Favorite URLs",																				  // STR_FAVORITE_URLS
	"Slot",																							  // STR_SLOT
	"Edit",																							  // STR_EDIT
	"One Time Url",																					  // STR_ONETIME_URL
	"Not a valid Package",																			  // STR_NOT_A_VALID_PACKAGE
	"Waiting for Package to finish installing",														  // STR_WAIT_FOR_INSTALL_MSG
	"Failed to install pkg file. Please delete the tmp pkg manually",								  // STR_FAIL_INSTALL_TMP_PKG_MSG
	"Failed to obtain download URL",																  // STR_FAIL_TO_OBTAIN_GG_DL_MSG
	"Auto delete temporary downloaded pkg file after install",										  // STR_AUTO_DELETE_TMP_PKG
	"Protocol not supported",																		  // STR_PROTOCOL_NOT_SUPPORTED
	"Could not resolve hostname",																	  // STR_COULD_NOT_RESOLVE_HOST
	"Extract",																						  // STR_EXTRACT
	"Extracting",																					  // STR_EXTRACTING
	"Failed to extract",																			  // STR_FAILED_TO_EXTRACT
	"Extract Location",																				  // STR_EXTRACT_LOCATION
	"Compress",																						  // STR_COMPRESS
	"Zip Filename",																					  // STR_ZIP_FILE_PATH
	"Compressing",																					  // STR_COMPRESSING
	"Error occured while creating zip",																  // STR_ERROR_CREATE_ZIP
	"Unsupported compressed file format",															  // STR_UNSUPPORTED_FILE_FORMAT
	"Cut",																							  // STR_CUT
	"Copy",																							  // STR_COPY
	"Paste",																						  // STR_PASTE
	"Move",																										  // STR_MOVE
	"Moving",																						  // STR_MOVING
	"Copying",																						  // STR_COPYING
	"Failed to move file",																			  // STR_FAIL_MOVE_MSG
	"Failed to copy file",																			  // STR_FAIL_COPY_MSG
	"Cannot move parent directory to sub subdirectory",												  // STR_CANT_MOVE_TO_SUBDIR_MSG
	"Cannot copy parent directory to sub subdirectory",												  // STR_CANT_COPY_TO_SUBDIR_MSG
	"Operation not supported",																		  // STR_UNSUPPORTED_OPERATION_MSG
	"Http Port",																					  // STR_HTTP_PORT
	"The content has already been installed. Do you want to continue installing",					  // STR_REINSTALL_CONFIRM_MSG
	"Remote package installation is not supported for protected servers.",							  // STR_REMOTE_NOT_SUPPORT_MSG
	"Remote HTTP Server not reachable.",															  // STR_CANNOT_CONNECT_REMOTE_MSG
	"Remote Package Install not possible. Would you like to download package and install?",			  // STR_DOWNLOAD_INSTALL_MSG
	"Checking remote server for Remote Package Install.",											  // STR_CHECKING_REMOTE_SERVER_MSG
	"RPI",																							  // STR_ENABLE_RPI
	"This option enables Remote Package Installation.",												  // STR_ENABLE_RPI_FTP_SMB_MSG
	"This option enables Remote Package Installation.",												  // STR_ENABLE_RPI_WEBDAV_MSG
	"Files",																						  // STR_FILES
	"Editor",																						  // STR_EDITOR
	"Save",																							  // STR_SAVE
	"Cannot edit files bigger than",																  // STR_MAX_EDIT_FILE_SIZE_MSG
	"Delete Selected Line",																			  // STR_DELETE_LINE
	"Insert Below Selected Line",																	  // STR_INSERT_LINE
	"Modified",																						  // STR_MODIFIED
	"Failed to obtain an access token from",														  // STR_FAIL_GET_TOKEN_MSG
	"Login Success. You may close the browser and return to the application",						  // STR_GET_TOKEN_SUCCESS_MSG
	"See, edit, create, and delete all of your Google Drive files",									  // STR_PERM_DRIVE
	"See, create, and delete its own configuration data in your Google Drive",						  // STR_PERM_DRIVE_APPDATA
	"See, edit, create, and delete only the specific Google Drive files you use with this app",		  // STR_PERM_DRIVE_FILE
	"View and manage metadata of files in your Google Drive",										  // STR_PERM_DRIVE_METADATA
	"See information about your Google Drive files",												  // STR_PERM_DRIVE_METADATA_RO
	"Google login failed",																			  // STR_GOOGLE_LOGIN_FAIL_MSG
	"Google login timed out",																		  // STR_GOOGLE_LOGIN_TIMEOUT_MSG
	"New File",																						  // STR_NEW_FILE
	"Settings",																						  // STR_SETTINGS
	"Client ID",																					  // STR_CLIENT_ID
	"Client Secret",																				  // STR_CLIENT_SECRET
	"Global",																						  // STR_GLOBAL
	"Google",																						  // STR_GOOGLE
	"Copy selected line",																			  // STR_COPY_LINE
	"Paste into selected line",																		  // STR_PASTE_LINE
	"Show hidden files",																			  // STR_SHOW_HIDDEN_FILES
	"Set Default Folder",																			  // STR_SET_DEFAULT_DIRECTORY
	"has being set as default direcotry",															  // STR_SET_DEFAULT_DIRECTORY_MSG
	"View Image",																					  // STR_VIEW_IMAGE
	"Package Information",																			  // STR_VIEW_PKG_INFO
	"NFS export path missing in URL",																  // STR_NFS_EXP_PATH_MISSING_MSG
	"Failed to init NFS context",																	  // STR_FAIL_INIT_NFS_CONTEXT
	"Failed to mount NFS share",																	  // STR_FAIL_MOUNT_NFS_MSG
	"Web Server",																					  // STR_WEB_SERVER
	"Enable",																						  // STR_ENABLE
	"Compressed Files Location",																	  // STR_COMPRESSED_FILE_PATH
	"Location of where compressed files are stored on the web server",								  // STR_COMPRESSED_FILE_PATH_MSG
	"AllDebrid",																					  // STR_ALLDEBRID
	"API Key",																						  // STR_API_KEY
	"Couldn't extract download url",																  // STR_CANT_EXTRACT_URL_MSG
	"Failed to install from URL",																	  // STR_FAIL_INSTALL_FROM_URL_MSG
	"InValid URL",																					  // STR_INVALID_URL
	"To use this function, an API Key needs to be configured in the ezRemote Client settings",		  // STR_ALLDEBRID_API_KEY_MISSING_MSG
	"Language",																						  // STR_LANGUAGE
	"Temp Directory",																				  // STR_TEMP_DIRECTORY
	"Real-Debrid",																					  // STR_REALDEBRID
	"Package install is running in the background. Don't close the app while install is in progress", // STR_BACKGROUND_INSTALL_INPROGRESS
	"Enable disk caching. Can improve package install speed in cases where connection to remote is slow, but breaks resuming of install",          // STR_ENABLE_DISC_CACHE_MSG
	"DC",                                                                                             // STR_ENABLE_DISK_CACHE
	"Install Via AllDebrid",                                                                          // STR_ENABLE_ALLDEBRID_MSG
	"Install Via RealDebrid",                                                                         // STR_ENABLE_REALDEBRID_MSG
	"Enable Disk Cache",                                                                              // STR_ENABLE_DISKCACHE_DESC
	"Cannot perform operation while activity is in progress",                                         // STR_ACTIVITY_IN_PROGRESS_MSG
	"ezRemote Direct Package Installer payload is not loaded",                                        // STR_ETAHEN_DPI_ERROR_MSG
	"Start/Restart Server",                                                                           // STR_RESTART_SERVER
	"Stop Server",                                                                                    // STR_STOP_SERVER
	"Warning",                                                                                        // STR_WARNING
	"The version of ezRemote Server payload running does not match the required version needed by ezRemote Client.", // STR_WARNING_MSG_1
	"If you are using Goldhen payload loader, then update the elf that comes with ezRemoteClient package.", // STR_WARNING_MSG_2
	"You may goto the Global Settings and restart ezRemote Server with the version that came packaged.", // STR_WARNING_MSG_3
	"Enable background download",                                                                     // STR_ENABLE_BG_DOWNLOAD
	"Minimum background file size (bytes)",                                                           // STR_BG_DOWNLOAD_MIN_SIZE
	"Background Download Progress",                                                                   // STR_BG_DOWNLOAD_PROGRESS
	"Show Background Download Progress",                                                              // STR_SHOW_BG_DOWNLOAD_PROGRESS
	"Running",																									  // STR_STATE_RUNNING
	"Done",																										  // STR_STATE_DONE
	"Failed",																									  // STR_STATE_FAILED
	"Cancelled",																								  // STR_STATE_CANCELLED
	"Partial",																									  // STR_STATE_PARTIAL
	"Native",																									  // STR_ORIGIN_NATIVE
	"Web",																										  // STR_ORIGIN_WEB
	"Activities",																								  // STR_ACTIVITIES
	"Clear completed",																						  // STR_CLEAR_COMPLETED
	"Clear history",																								  // STR_CLEAR_HISTORY
	"Show activities dialog on new activity",											  // STR_SHOW_ACTIVITIES_DIALOG
	"Skip",																											  // STR_SKIP
	"Always overwrite",																						  // STR_ALWAYS_OVERWRITE
	"Cancelling…",																								  // STR_CANCELLING
	"Use only from a web browser (no console screen)",																								  // STR_HEADLESS_MODE
	"ezRemote Client started in web browser mode",																								  // STR_HEADLESS_STARTED_MSG
	"ezRemote Client browse mode is closing",																								  // STR_CLOSING_MSG
};

bool needs_extended_font = false;

static std::map<std::string, std::string> lang_file_cache;

// /app0 files become unreadable once the app has been running for a while
// (the same reason the font files had to be cached), so snapshot every
// language file on first use and parse from memory afterwards.
// Before JBC only /app0 is readable; afterwards the pfsmnt path is. Try both.
static bool ReadLanguageFile(const std::string &name, std::string *out)
{
    const char *roots[] = {
        LANG_ASSETS_ROOT "/",
#ifndef EZREMOTE_HEADLESS_APP
        "/app0/assets/langs/",
#endif
    };
    for (size_t i = 0; i < sizeof(roots) / sizeof(roots[0]); i++)
    {
        std::string path = std::string(roots[i]) + name;
        FILE *fp = fopen(path.c_str(), "rb");
        if (fp == nullptr)
            continue;
        fseek(fp, 0, SEEK_END);
        long size = ftell(fp);
        fseek(fp, 0, SEEK_SET);
        if (size > 0)
        {
            std::string content;
            content.resize((size_t) size);
            size_t read = fread(&content[0], 1, content.size(), fp);
            if (read == content.size())
            {
                *out = content;
                fclose(fp);
                return true;
            }
        }
        fclose(fp);
    }
    return false;
}

static void CacheLanguageFiles()
{
	if (!lang_file_cache.empty())
		return;

	// Read the known language list first; this covers every shipped file even
	// if directory enumeration is restricted.
	for (size_t i = 0; i < langs.size(); i++)
	{
		if (langs[i].compare("Default") == 0)
			continue;

		std::string name = langs[i] + ".ini";
		std::string content;
		if (ReadLanguageFile(name, &content))
			lang_file_cache[name] = content;
	}

	const char *lang_root = LANG_ASSETS_ROOT;
	DIR *dir = opendir(lang_root);
#ifndef EZREMOTE_HEADLESS_APP
	if (dir == nullptr)
	{
		lang_root = "/app0/assets/langs";
		dir = opendir(lang_root);
	}
#endif
	if (dir == nullptr)
		return;

	struct dirent *entry;
	while ((entry = readdir(dir)) != nullptr)
	{
		std::string name = entry->d_name;
		if (name.size() < 5 || name.compare(name.size() - 4, 4, ".ini") != 0)
			continue;

		std::string content;
		if (ReadLanguageFile(name, &content))
			lang_file_cache[name] = content;
	}

	closedir(dir);
}

static void ParseLanguageContent(const std::string &content)
{
	size_t pos = 0;
	while (pos < content.size())
	{
		size_t end = content.find('\n', pos);
		std::string line = content.substr(pos, end == std::string::npos ? std::string::npos : end - pos);
		pos = (end == std::string::npos) ? content.size() : end + 1;

		if (!line.empty() && line[line.size() - 1] == '\r')
			line.erase(line.size() - 1);

		size_t separator = line.find('=');
		if (separator == std::string::npos)
			continue;

		std::string key = line.substr(0, separator);
		std::string value = line.substr(separator + 1);

		for (int i = 0; i < LANG_STRINGS_NUM; i++)
		{
			if (key.compare(lang_identifiers[i]) != 0)
				continue;

			std::string unescaped;
			unescaped.reserve(value.size());
			for (size_t c = 0; c < value.size(); c++)
			{
				if (value[c] == '\\' && c + 1 < value.size() && value[c + 1] == 'n')
				{
					unescaped += '\n';
					c++;
				}
				else
				{
					unescaped += value[c];
				}
			}

			strncpy(lang_strings[i], unescaped.c_str(), LANG_STR_SIZE - 1);
			lang_strings[i][LANG_STR_SIZE - 1] = '\0';
			break;
		}
	}
}

namespace Lang
{
	static bool reload_pending = false;
	static std::string applied_language;
	static int32_t system_lang_idx = 0;

	void SetSystemLangIndex(int32_t lang_idx)
	{
		system_lang_idx = lang_idx;
	}

	void RequestReload()
	{
		reload_pending = true;
	}

	void SyncRequest()
	{
		if (applied_language != std::string(language))
			reload_pending = true;
	}

	bool ApplyPendingReload()
	{
		if (!reload_pending)
			return false;

		reload_pending = false;
		SetTranslation(system_lang_idx);
		applied_language = std::string(language);
		return true;
	}

	void SetTranslation(int32_t lang_idx)
	{
		char langFile[LANG_STR_SIZE * 2];
		char identifier[LANG_ID_SIZE], buffer[LANG_STR_SIZE];

		std::string lang = std::string(language);
		lang = Util::Trim(lang, " ");
		if (lang.size() > 0 && lang.compare("Default") != 0)
		{
			sprintf(langFile, LANG_ASSETS_ROOT "/%s.ini", lang.c_str());
		}
		else
		{
			switch (lang_idx)
			{
			case ORBIS_SYSTEM_PARAM_LANG_ITALIAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Italiano.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_SPANISH:
			case ORBIS_SYSTEM_PARAM_LANG_SPANISH_LA:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Spanish.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_GERMAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/German.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_PORTUGUESE_PT:
			case ORBIS_SYSTEM_PARAM_LANG_PORTUGUESE_BR:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Portuguese_BR.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_RUSSIAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Russian.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_DUTCH:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Dutch.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_FRENCH:
			case ORBIS_SYSTEM_PARAM_LANG_FRENCH_CA:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/French.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_POLISH:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Polish.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_JAPANESE:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Japanese.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_KOREAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Korean.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_CHINESE_S:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Simplified Chinese.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_CHINESE_T:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Traditional Chinese.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_INDONESIAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Indonesian.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_HUNGARIAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Hungarian.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_GREEK:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Greek.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_VIETNAMESE:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Vietnamese.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_TURKISH:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Turkish.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_ARABIC:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Arabic.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_ROMANIAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Romanian.ini");
				break;
			case ORBIS_SYSTEM_PARAM_LANG_NORWEGIAN:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/Norwegian.ini");
				break;
			default:
				sprintf(langFile, "%s", LANG_ASSETS_ROOT "/English.ini");
				break;
			}
		}

		CacheLanguageFiles();

		std::string fileName = langFile;
		size_t slash = fileName.find_last_of('/');
		std::string baseName = (slash == std::string::npos) ? fileName : fileName.substr(slash + 1);

		std::map<std::string, std::string>::iterator cached = lang_file_cache.find(baseName);
		if (cached != lang_file_cache.end())
		{
			ParseLanguageContent(cached->second);
		}
		else
		{
			std::string content;
			if (ReadLanguageFile(baseName, &content))
			{
				ParseLanguageContent(content);
			}
			else
			{
				FILE *config = fopen(langFile, "r");
				if (config)
				{
					char chunk[4096];
					size_t read;
					while ((read = fread(chunk, 1, sizeof(chunk), config)) > 0)
						content.append(chunk, read);
					fclose(config);
					ParseLanguageContent(content);
				}
			}
		}

		char buf[12];
		int num;
		sscanf(last_site, "%[^ ] %d", buf, &num);
		sprintf(display_site, "%s %d", lang_strings[STR_SITE], num);
		applied_language = std::string(language);
	}
}
