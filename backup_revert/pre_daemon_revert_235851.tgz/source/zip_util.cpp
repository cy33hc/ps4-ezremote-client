
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <new>
#include <unistd.h>
#include <dirent.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <minizip/unzip.h>
#include <minizip/zip.h>
#include <archive.h>
#include <archive_entry.h>
#include <orbis/SystemService.h>

#include "clients/remote_client.h"
#include "config.h"
#include "common.h"
#include "fs.h"
#ifndef EZREMOTE_HEADLESS_APP
#include "ime_dialog.h"
#endif
#include "lang.h"
#include "system.h"
#include "ui_state.h"
#include "util.h"
#include "zip_util.h"
#include "activity.h"

namespace ZipUtil
{
    static char filename_extracted[256];
    static char password[128];

    void convertToZipTime(time_t time, tm_zip *tmzip)
    {
        OrbisDateTime gmt;
        OrbisDateTime lt;

        struct tm tm = *localtime(&time);
        gmt.day = tm.tm_mday;
        gmt.month = tm.tm_mon + 1;
        gmt.year = tm.tm_year + 1900;
        gmt.hour = tm.tm_hour;
        gmt.minute = tm.tm_min;
        gmt.second = tm.tm_sec;

        convertUtcToLocalTime(&gmt, &lt);

        tmzip->tm_sec = lt.second;
        tmzip->tm_min = lt.minute;
        tmzip->tm_hour = lt.hour;
        tmzip->tm_mday = lt.day;
        tmzip->tm_mon = lt.month;
        tmzip->tm_year = lt.year;
    }

    int ZipAddFile(zipFile zf, const std::string &path, int filename_start, int level)
    {
        int res;
        // Get file stat
        struct stat file_stat;
        memset(&file_stat, 0, sizeof(file_stat));
        res = stat(path.c_str(), &file_stat);
        if (res < 0)
            return res;

        // Get file local time
        zip_fileinfo zi;
        memset(&zi, 0, sizeof(zip_fileinfo));
        convertToZipTime(file_stat.st_mtim.tv_sec, &zi.tmz_date);

        uint64_t copied = 0;

        const uint64_t total_size = file_stat.st_size;

        // Large file?
        int use_zip64 = (file_stat.st_size >= 0xFFFFFFFF);

        // Open new file in zip
        res = zipOpenNewFileInZip3_64(zf, path.substr(filename_start).c_str(), &zi,
                                      NULL, 0, NULL, 0, NULL,
                                      (level != 0) ? Z_DEFLATED : 0,
                                      level, 0,
                                      -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY,
                                      NULL, 0, use_zip64);
        if (res < 0)
            return res;

        // Open file to add
        FILE *fd = FS::OpenRead(path);
        if (fd == NULL)
        {
            zipCloseFileInZip(zf);
            return 0;
        }

        // Add file to zip
#ifdef EZREMOTE_HEADLESS_APP
        void *buf = nullptr;
        if (posix_memalign(&buf, 4096, ARCHIVE_TRANSFER_SIZE) != 0)
            buf = nullptr;
#else
        void *buf = memalign(4096, ARCHIVE_TRANSFER_SIZE);
#endif
        uint64_t seek = 0;

        while (1)
        {
            // Cancelled mid-file: close the entry so the archive stays readable
            // and leave the partial archive for the user to delete.
            if (Activities::Stopped())
            {
                free(buf);
                FS::Close(fd);
                zipCloseFileInZip(zf);
                return 0;
            }

            int read = FS::Read(fd, buf, ARCHIVE_TRANSFER_SIZE);
            if (read < 0)
            {
                free(buf);
                FS::Close(fd);
                zipCloseFileInZip(zf);
                return read;
            }

            if (read == 0)
                break;

            int written = zipWriteInFileInZip(zf, buf, read);
            if (written < 0)
            {
                free(buf);
                FS::Close(fd);
                zipCloseFileInZip(zf);
                return written;
            }

            seek += written;
            copied += read;
            Activities::ProgressCurrent(copied, total_size);
        }

        free(buf);
        FS::Close(fd);
        zipCloseFileInZip(zf);

        return 1;
    }

    int ZipAddFolder(zipFile zf, const std::string &path, int filename_start, int level)
    {
        int res;

        // Get file stat
        struct stat file_stat;
        memset(&file_stat, 0, sizeof(file_stat));
        res = stat(path.c_str(), &file_stat);
        if (res < 0)
            return res;

        // Get file local time
        zip_fileinfo zi;
        memset(&zi, 0, sizeof(zip_fileinfo));
        convertToZipTime(file_stat.st_mtim.tv_sec, &zi.tmz_date);

        // Open new file in zip
        std::string folder = path.substr(filename_start);
        if (folder[folder.length() - 1] != '/')
            folder = folder + "/";

        res = zipOpenNewFileInZip3_64(zf, folder.c_str(), &zi,
                                      NULL, 0, NULL, 0, NULL,
                                      (level != 0) ? Z_DEFLATED : 0,
                                      level, 0,
                                      -MAX_WBITS, DEF_MEM_LEVEL, Z_DEFAULT_STRATEGY,
                                      NULL, 0, 0);

        if (res < 0)
            return res;

        zipCloseFileInZip(zf);
        return 1;
    }

    int ZipAddPath(zipFile zf, const std::string &path, int filename_start, int level)
    {
        DIR *dfd = opendir(path.c_str());
        if (dfd != NULL)
        {
            int ret = ZipAddFolder(zf, path, filename_start, level);
            if (ret <= 0)
                return ret;

            struct dirent *dirent;
            do
            {
                dirent = readdir(dfd);
                if (Activities::Stopped())
                    return 1;
                if (dirent != NULL && strcmp(dirent->d_name, ".") != 0 && strcmp(dirent->d_name, "..") != 0)
                {
                    int new_path_length = path.length() + strlen(dirent->d_name) + 2;
                    char *new_path = (char *)malloc(new_path_length);
                    snprintf(new_path, new_path_length, "%s%s%s", path.c_str(), FS::hasEndSlash(path.c_str()) ? "" : "/", dirent->d_name);

                    int ret = 0;

                    if (dirent->d_type & DT_DIR)
                    {
                        ret = ZipAddPath(zf, new_path, filename_start, level);
                    }
                    else
                    {
                        sprintf(activity_message, "%s %s", lang_strings[STR_COMPRESSING], new_path);
                        ret = ZipAddFile(zf, new_path, filename_start, level);
                    }

                    free(new_path);

                    // Some folders are protected and return 0x80010001. Bypass them
                    if (ret <= 0)
                    {
                        closedir(dfd);
                        return ret;
                    }
                }
            } while (dirent != NULL);

            closedir(dfd);
        }
        else
        {
            sprintf(activity_message, "%s %s", lang_strings[STR_COMPRESSING], path.c_str());
            return ZipAddFile(zf, path, filename_start, level);
        }

        return 1;
    }

    /* duplicate a path name, possibly converting to lower case */
    static char *pathdup(const char *path)
    {
        char *str;
        size_t i, len;

        if (path == NULL || path[0] == '\0')
            return (NULL);

        len = strlen(path);
        while (len && path[len - 1] == '/')
            len--;
        if ((str = (char *)malloc(len + 1)) == NULL)
        {
            errno = ENOMEM;
        }
        memcpy(str, path, len);

        str[len] = '\0';

        return (str);
    }

    /* concatenate two path names */
    static char *pathcat(const char *prefix, const char *path)
    {
        char *str;
        size_t prelen, len;

        prelen = prefix ? strlen(prefix) + 1 : 0;
        len = strlen(path) + 1;
        if ((str = (char *)malloc(prelen + len)) == NULL)
        {
            errno = ENOMEM;
        }
        if (prefix)
        {
            memcpy(str, prefix, prelen); /* includes zero */
            str[prelen - 1] = '/';       /* splat zero */
        }
        memcpy(str + prelen, path, len); /* includes zero */

        return (str);
    }

    /*
     * Extract a directory.
     */
    static void extract_dir(struct archive *a, struct archive_entry *e, const std::string &path)
    {
        int mode;

        if (path[0] == '\0')
            return;

        FS::MkDirs(path);
        archive_read_data_skip(a);
    }

    /*
     * Extract to a file descriptor
     */
    static int extract2fd(struct archive *a, const std::string &pathname, int fd)
    {
        ssize_t len;
        unsigned char *buffer = (unsigned char *)malloc(ARCHIVE_TRANSFER_SIZE);

        /* loop over file contents and write to fd */
        for (int n = 0;; n++)
        {
            // Cancelled mid-file: stop here and keep what was written, the way
            // Explorer leaves a partly extracted file.
            if (Activities::Stopped())
            {
                free(buffer);
                return 0;
            }

            len = archive_read_data(a, buffer, ARCHIVE_TRANSFER_SIZE);

            if (len == 0)
            {
                free(buffer);
                return 1;
            }

            if (len < 0)
            {
                sprintf(status_message, "error archive_read_data('%s')", pathname.c_str());
                free(buffer);
                return 0;
            }
            if (write(fd, buffer, len) != len)
            {
                sprintf(status_message, "error write('%s')", pathname.c_str());
                free(buffer);
                return 0;
            }
        }

        free(buffer);
        return 1;
    }

    /*
     * Extract a regular file.
     */
    static void extract_file(struct archive *a, struct archive_entry *e, const std::string &path)
    {
        struct stat sb;
        int fd;
        const char *linkname;

        /* look for existing file of same name */
    recheck:
        if (lstat(path.c_str(), &sb) == 0)
        {
            (void)unlink(path.c_str());
        }

        /* process symlinks */
        linkname = archive_entry_symlink(e);
        if (linkname != NULL)
        {
            if (symlink(linkname, path.c_str()) != 0)
            {
                sprintf(status_message, "error symlink('%s')", path.c_str());
                return;
            }

            /* set access and modification time */
            return;
        }

        const uint64_t total_size = archive_entry_size(e);
        if ((fd = open(path.c_str(), O_RDWR | O_CREAT | O_TRUNC, 0777)) < 0)
        {
            sprintf(status_message, "error open('%s')", path.c_str());
            return;
        }

        extract2fd(a, path, fd);

        /* set access and modification time */
        if (close(fd) != 0)
        {
            return;
        }
    }

    static void extract(struct archive *a, struct archive_entry *e, const std::string &base_dir)
    {
        char *pathname, *realpathname;
        mode_t filetype;
        const char *entry_pathname;
        bool is_dir;

        entry_pathname = archive_entry_pathname(e);

        if ((pathname = pathdup(entry_pathname)) == NULL)
        {
            archive_read_data_skip(a);
            return;
        }
        filetype = archive_entry_filetype(e);

        /*
         * libarchive reports some directory entries as regular files. A
         * trailing '/' is the archive convention for a directory, so trust
         * that as well: if such an entry is extracted as a file, every entry
         * below that folder fails with ENOTDIR and nothing is extracted.
         */
        is_dir = S_ISDIR(filetype) ||
                 (entry_pathname != NULL && entry_pathname[0] != '\0' && entry_pathname[strlen(entry_pathname) - 1] == '/');

        /* sanity checks */
        if (pathname[0] == '/' ||
            strncmp(pathname, "../", 3) == 0 ||
            strstr(pathname, "/../") != NULL)
        {
            archive_read_data_skip(a);
            free(pathname);
            return;
        }

        /* I don't think this can happen in a zipfile.. */
        if (!is_dir && !S_ISREG(filetype) && !S_ISLNK(filetype))
        {
            archive_read_data_skip(a);
            free(pathname);
            return;
        }

        realpathname = pathcat(base_dir.c_str(), pathname);

        /* ensure that parent directory exists */
        FS::MkDirs(realpathname, true);

        if (is_dir)
            extract_dir(a, e, realpathname);
        else
        {
            snprintf(activity_message, 255, "%s: %s", lang_strings[STR_EXTRACTING], pathname);
            
            /* ensure that parent directory exists */
            FS::MkDirs(realpathname, true);

            Activities::Item(Activities::CurrentId(), pathname);
            extract_file(a, e, realpathname);
        }

        free(realpathname);
        free(pathname);
    }

    /*
     * Callback function for reading passphrase.
     * Originally from cpio.c and passphrase.c, libarchive.
     */
    static const char *passphrase_callback(struct archive *a, void *_client_data)
    {
        memset(password, 0, sizeof(password));

#ifdef EZREMOTE_HEADLESS_APP
        // Headless build: there is no UI to ask for a passphrase.
        return password;
#else
        /* Extraction runs on a worker thread. An IME dialog can only be pumped
         * from the UI thread, and if one is already open (e.g. the user is
         * editing something) we must not terminate it from here and use its
         * text as the archive password. */
        while (Dialog::isImeDialogRunning())
        {
            /* Let the user cancel the extraction while waiting */
            if (Activities::Stopped())
                return password;

            sceKernelUsleep(10000);
        }

        if (Dialog::initImeDialog(lang_strings[STR_PASSWORD], password, 127, ORBIS_TYPE_DEFAULT, 560, 200) < 0)
        {
            /* Dialog could not be started; return an empty passphrase so
             * libarchive reports the failure instead of hanging. */
            return password;
        }

        if (Dialog::updateImeDialog() == IME_DIALOG_RESULT_FINISHED)
        {
            snprintf(password, sizeof(password) - 1, "%s", (char *)Dialog::getImeDialogInputText());
        }
#endif

        return password;
    }

    static RemoteArchiveData *OpenRemoteArchive(const std::string &file, RemoteClient *client)
    {
        RemoteArchiveData *data;

        /* RemoteArchiveData holds a std::string, so it must be created with new
         * (malloc/memset would leave the string uninitialized). */
        data = new (std::nothrow) RemoteArchiveData;
        if (data == nullptr)
            return nullptr;

        data->fp = nullptr;
        data->client = client;
        data->path = file;
        data->size = 0;
        data->offset = 0;

        uint64_t remote_size = 0;
        client->Size(file, &remote_size);
        data->size = (ssize_t) remote_size;
        if (client->SupportedActions() & REMOTE_ACTION_RAW_READ)
        {
            data->fp = client->Open(file, O_RDONLY);
        }
        return data;
    }

    static ssize_t ReadRemoteArchive(struct archive *a, void *client_data, const void **buff)
    {
        ssize_t to_read;
        int ret;
        RemoteArchiveData *data;

        data = (RemoteArchiveData *)client_data;
        *buff = data->buf;

        to_read = data->size - data->offset;
        if (to_read == 0)
            return 0;

        to_read = MIN(to_read, ARCHIVE_TRANSFER_SIZE);
        if (data->client->SupportedActions() & REMOTE_ACTION_RAW_READ)
            ret = data->client->GetRange((data->fp), data->buf, to_read, data->offset);
        else
            ret = data->client->GetRange(data->path, data->buf, to_read, data->offset);

        if (ret == 0)
            return -1;
        data->offset = data->offset + to_read;

        // Archive-level progress: bytes consumed of the whole archive.
        Activities::ProgressCurrent(data->offset, data->size);

        return to_read;
    }

    static int CloseRemoteArchive(struct archive *a, void *client_data)
    {
        if (client_data != nullptr)
        {
            RemoteArchiveData *data = (RemoteArchiveData *)client_data;
            if (data->client->SupportedActions() & REMOTE_ACTION_RAW_READ)
                data->client->Close(data->fp);
            delete data;
        }
        return 0;
    }

    int64_t SeekRemoteArchive(struct archive *, void *client_data, int64_t offset, int whence)
    {
        RemoteArchiveData *data = (RemoteArchiveData *)client_data;

        if (whence == SEEK_SET)
        {
            data->offset = offset;
        }
        else if (whence == SEEK_CUR)
        {
            data->offset = data->offset + offset;
        }
        else if (whence == SEEK_END)
        {
            data->offset = data->size + offset;
        }
        else
            return ARCHIVE_FATAL;

        return data->offset;
    }

    int64_t SkipRemoteArchive(struct archive *, void *client_data, int64_t request)
    {
        RemoteArchiveData *data = (RemoteArchiveData *)client_data;

        data->offset = data->offset + request;

        return request;
    }

    /*
     * Main loop: open the zipfile, iterate over its contents and decide what
     * to do with each entry.
     */
    int Extract(const DirEntry &file, const std::string &basepath, RemoteClient *client)
    {
        struct archive *a;
        struct archive_entry *e;
        RemoteArchiveData *client_data = nullptr;
        int ret;
        uintmax_t total_size, file_count, error_count;

        if ((a = archive_read_new()) == NULL)
        {
            sprintf(status_message, "%s", "archive_read_new failed");
            return 0;
        }

        archive_read_support_format_all(a);
        archive_read_support_filter_all(a);
        archive_read_set_passphrase_callback(a, NULL, &passphrase_callback);

        if (client == nullptr)
        {
            ret = archive_read_open_filename(a, file.path, ARCHIVE_TRANSFER_SIZE);
            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "%s", "archive_read_open_filename failed");
                archive_read_free(a);
                return 0;
            }
        }
        else
        {
            client_data = OpenRemoteArchive(file.path, client);
            if (client_data == nullptr)
            {
                sprintf(status_message, "%s", "archive_read_open_filename failed");
                archive_read_free(a);
                return 0;
            }

            ret = archive_read_set_seek_callback(a, SeekRemoteArchive);
            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "archive_read_set_seek_callback failed - %s", archive_error_string(a));
                /* The archive was never opened, so its close callback will not
                 * release the client data. */
                delete client_data;
                archive_read_free(a);
                return 0;
            }

            ret = archive_read_open2(a, client_data, NULL, ReadRemoteArchive, SkipRemoteArchive, CloseRemoteArchive);
            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "%s", "archive_read_open failed");
                archive_read_free(a);
                return 0;
            }
        }

        FS::MkDirs(basepath.c_str());

        uint64_t archive_total = 0;
        if (client == nullptr)
            archive_total = (uint64_t) FS::GetSize(file.path);

        for (;;)
        {
            if (Activities::Stopped())
                break;

            ret = archive_read_next_header(a, &e);

            if (ret == ARCHIVE_EOF)
                break;

            if (ret == ARCHIVE_RETRY)
                continue;

            /*
             * ARCHIVE_WARN only means this entry had a problem (bsdtar keeps
             * going as well). Aborting here made a single questionable entry
             * fail the whole extraction.
             */
            if (ret == ARCHIVE_WARN)
            {
                const char *err = archive_error_string(a);
                sprintf(status_message, "%s", err != NULL ? err : "");
                continue;
            }

            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "%s", "archive_read_next_header failed");
                archive_read_free(a);
                return 0;
            }

            extract(a, e, basepath);

            if (client == nullptr && archive_total > 0)
                Activities::ProgressCurrent((uint64_t) archive_filter_bytes(a, 0), archive_total);
        }

        archive_read_free(a);

        return 1;
    }

    ArchiveEntry *GetPackageEntry(const std::string &zip_file, RemoteClient *client)
    {
        struct archive *a;
        struct archive_entry *e;
        RemoteArchiveData *client_data = nullptr;
        char *pathname;
        mode_t filetype;
        ArchiveEntry *pkg_entry = nullptr;
        int ret;

        if ((a = archive_read_new()) == NULL)
        {
            sprintf(status_message, "%s", "archive_read_new failed");
            return nullptr;
        }

        archive_read_support_format_all(a);
        archive_read_support_filter_all(a);
        archive_read_set_passphrase_callback(a, NULL, &passphrase_callback);

        if (client == nullptr)
        {
            ret = archive_read_open_filename(a, zip_file.c_str(), ARCHIVE_TRANSFER_SIZE);
            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "%s", "archive_read_open_filename failed");
                archive_read_free(a);
                return nullptr;
            }
        }
        else
        {
            client_data = OpenRemoteArchive(zip_file, client);
            if (client_data == nullptr)
            {
                sprintf(status_message, "%s", "archive_read_open_filename failed");
                archive_read_free(a);
                return nullptr;
            }

            ret = archive_read_set_seek_callback(a, SeekRemoteArchive);
            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "archive_read_set_seek_callback failed - %s", archive_error_string(a));
                /* The archive was never opened, so its close callback will not
                 * release the client data. */
                delete client_data;
                archive_read_free(a);
                return nullptr;
            }

            ret = archive_read_open2(a, client_data, NULL, ReadRemoteArchive, SkipRemoteArchive, CloseRemoteArchive);
            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "%s", "archive_read_open_filename failed");
                archive_read_free(a);
                return nullptr;
            }
        }

        for (;;)
        {
            ret = archive_read_next_header(a, &e);

            if (ret == ARCHIVE_EOF)
            {
                break;
            }

            /* ARCHIVE_WARN is not fatal; skip the entry and keep looking. */
            if (ret == ARCHIVE_WARN || ret == ARCHIVE_RETRY)
            {
                archive_read_data_skip(a);
                continue;
            }

            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "%s", "archive_read_next_header failed");
                archive_read_free(a);
                return nullptr;
            }

            if ((pathname = pathdup(archive_entry_pathname(e))) == NULL)
            {
                archive_read_data_skip(a);
                continue;
            }

            filetype = archive_entry_filetype(e);

            /* sanity checks */
            if (pathname[0] == '/' ||
                strncmp(pathname, "../", 3) == 0 ||
                strstr(pathname, "/../") != NULL)
            {
                archive_read_data_skip(a);
                free(pathname);
                continue;
                ;
            }

            /* I don't think this can happen in a zipfile.. */
            if (!S_ISREG(filetype))
            {
                archive_read_data_skip(a);
                free(pathname);
                continue;
            }

            if (Util::EndsWith(Util::ToLower(pathname), ".pkg"))
            {
                pkg_entry = (ArchiveEntry *)malloc(sizeof(ArchiveEntry));
                memset(pkg_entry, 0, sizeof(ArchiveEntry));

                pkg_entry->archive = a;
                pkg_entry->entry = e;
                pkg_entry->client_data = client_data;
                pkg_entry->filename = pathname;
                pkg_entry->filesize = archive_entry_size(e);

                free(pathname);
                return pkg_entry;
            }

            free(pathname);
        }

        archive_read_free(a);

        return nullptr;
    }

    ArchiveEntry *GetNextPackageEntry(ArchiveEntry *archive_entry)
    {
        struct archive *a = archive_entry->archive;
        struct archive_entry *e = nullptr;
        RemoteArchiveData *client_data = archive_entry->client_data;
        char *pathname;
        mode_t filetype;
        ArchiveEntry *pkg_entry = nullptr;
        int ret;

        for (;;)
        {
            ret = archive_read_next_header(a, &e);

            if (ret == ARCHIVE_EOF)
                break;

            /* ARCHIVE_WARN is not fatal; skip the entry and keep looking. */
            if (ret == ARCHIVE_WARN || ret == ARCHIVE_RETRY)
            {
                archive_read_data_skip(a);
                continue;
            }

            if (ret < ARCHIVE_OK)
            {
                sprintf(status_message, "%s", "archive_read_next_header failed");
                archive_read_free(a);
                return nullptr;
            }

            if ((pathname = pathdup(archive_entry_pathname(e))) == NULL)
            {
                archive_read_data_skip(a);
                continue;
            }

            filetype = archive_entry_filetype(e);

            /* sanity checks */
            if (pathname[0] == '/' ||
                strncmp(pathname, "../", 3) == 0 ||
                strstr(pathname, "/../") != NULL)
            {
                archive_read_data_skip(a);
                free(pathname);
                continue;
                ;
            }

            /* I don't think this can happen in a zipfile.. */
            if (!S_ISREG(filetype))
            {
                archive_read_data_skip(a);
                free(pathname);
                continue;
            }

            if (Util::EndsWith(Util::ToLower(pathname), ".pkg"))
            {
                pkg_entry = (ArchiveEntry *)malloc(sizeof(ArchiveEntry));
                memset(pkg_entry, 0, sizeof(ArchiveEntry));

                pkg_entry->archive = a;
                pkg_entry->entry = e;
                pkg_entry->client_data = client_data;
                pkg_entry->filename = pathname;
                pkg_entry->filesize = archive_entry_size(e);

                free(pathname);
                return pkg_entry;
            }

            free(pathname);
        }

        archive_read_free(a);

        return nullptr;
    }
}